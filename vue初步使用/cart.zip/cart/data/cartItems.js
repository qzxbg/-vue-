let cartItems = [
    {
        "id": 1,
        "classification": "手机",
        "name": "荣耀9X",
        "price": 129900,
        "cover": "dc5164850933d966.jpg",
        "quantity": 2,
        "checked": false
    },
    {
        "id": 2,
        "classification": "手机",
        "name": "Redmi 8A",
        "price": 69900,
        "cover": "68d0ac29ce4a326d.jpg",
        "quantity": 1,
        "checked": false
    },
    {
        "id": 3,
        "classification": "手机",
        "name": "荣耀20青春版",
        "price": 119900,
        "cover": "79c4d1ea436ed9ea.jpg",
        "quantity": 1,
        "checked": false
    },
    {
        "id": 4,
        "classification": "手机",
        "name": "荣耀Play4T Pro",
        "price": 149900,
        "cover": "d2db1412dcce1d96.jpg",
        "quantity": 1,
        "checked": false
    }
]